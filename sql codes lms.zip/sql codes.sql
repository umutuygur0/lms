CREATE DATABASE Projectlast;
USE Projectlast;

CREATE TABLE Account (
    Account_ID INT PRIMARY KEY NOT NULL UNIQUE,
    Account_TYPE INT NOT NULL,
    Username VARCHAR(45),
    Password VARCHAR(45),
    INDEX idx_Username (Username),
    INDEX idx_Account_TYPE (Account_TYPE),
    CONSTRAINT CheckAccountType CHECK (Account_TYPE IN (0, 1, 2))
);

-- Student Table
CREATE TABLE Student (
    Student_ID INT PRIMARY KEY NOT NULL UNIQUE,
    Student_Name VARCHAR(45) NOT NULL,
    Enrollment_Date DATE NOT NULL,
    Phone_num VARCHAR(45) NOT NULL UNIQUE,
    Email VARCHAR(45) NOT NULL UNIQUE,
    Graduation_Date VARCHAR(45),
    account_Account_ID INT NOT NULL UNIQUE,
    CONSTRAINT FK_StudentAccount FOREIGN KEY (account_Account_ID) REFERENCES Account(Account_ID) ON DELETE CASCADE,
    CONSTRAINT CheckEnrollmentBeforeGraduation CHECK (
        (Enrollment_Date IS NULL AND Graduation_Date IS NULL) OR 
        (Enrollment_Date IS NOT NULL AND Graduation_Date IS NOT NULL AND Enrollment_Date <= Graduation_Date)
    ),
    INDEX idx_Enrollment_Date (Enrollment_Date),
    INDEX idx_Phone_num (Phone_num),
    INDEX idx_Email (Email)
);

-- Instructor Table
CREATE TABLE Instructor (
    Ins_ID INT PRIMARY KEY NOT NULL UNIQUE,
    Instructor_Name VARCHAR(45) NOT NULL,
    Phone_num VARCHAR(45) NOT NULL UNIQUE,
    Email VARCHAR(45) NOT NULL UNIQUE,
    account_Account_ID INT NOT NULL UNIQUE,
    CONSTRAINT FK_InstructorAccount FOREIGN KEY (account_Account_ID) REFERENCES Account(Account_ID) ON DELETE CASCADE,
    INDEX idx_Phone_num (Phone_num),
    INDEX idx_Email (Email)
);

-- Administration Table
CREATE TABLE Administration (
    Admin_ID INT PRIMARY KEY NOT NULL UNIQUE,
    Admin_Name VARCHAR(45) NOT NULL,
    account_Account_ID INT NOT NULL UNIQUE,
    CONSTRAINT FK_AdministrationAccount FOREIGN KEY (account_Account_ID) REFERENCES Account(Account_ID) ON DELETE CASCADE
);

-- Support Table
CREATE TABLE Support (
    Help_ID INT PRIMARY KEY AUTO_INCREMENT,
    Administration_Admin_ID INT DEFAULT NULL,
    AC_Account_ID INT NOT NULL,
    Content LONGTEXT NOT NULL,
    CONSTRAINT FK_AdminSupport FOREIGN KEY (Administration_Admin_ID) REFERENCES Administration(Admin_ID),
    CONSTRAINT FK_AC_Account_IDSupport FOREIGN KEY (AC_Account_ID) REFERENCES Account(Account_ID) ON DELETE CASCADE
);

-- Course Table
CREATE TABLE Course (
    Course_ID INT PRIMARY KEY NOT NULL UNIQUE,
    Abstract VARCHAR(45) NOT NULL,
    Course_Name VARCHAR(45) NOT NULL,
    Semester VARCHAR(45) NOT NULL,
    Coursepage_content TEXT
);
CREATE INDEX idx_course_name ON Course(Course_Name);

CREATE TABLE Course_Instructor (
    Course_ID INT,
    Instructor_ID INT,
    PRIMARY KEY (Course_ID, Instructor_ID),
    FOREIGN KEY (Course_ID) REFERENCES Course(Course_ID),
    FOREIGN KEY (Instructor_ID) REFERENCES Instructor(Ins_ID)
);

-- Assignment Table
CREATE TABLE Assignment (
    Assignment_ID INT AUTO_INCREMENT PRIMARY KEY,
    Course_ID INT,
    Title VARCHAR(255),
    Deadline DATE,
    Content LONGTEXT,
    Student_ID INT,
    Submission_Content LONGTEXT,
    Grade VARCHAR(10),
    Feedback_Content LONGTEXT,
    FOREIGN KEY (Course_ID) REFERENCES Course(Course_ID),
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID) ON DELETE CASCADE
);

-- Feedback Table
CREATE TABLE Feedback (
    Feedback_Num INT PRIMARY KEY NOT NULL UNIQUE,
    Content LONGTEXT NOT NULL,
    Instructor_Ins_ID INT NOT NULL,
    Student_Student_ID INT NOT NULL,
    Grade INT NOT NULL DEFAULT 0,
    Assignment_Assignment_ID INT NOT NULL,
    CONSTRAINT FK_FeedbackInstructor FOREIGN KEY (Instructor_Ins_ID) REFERENCES Instructor(Ins_ID),
    CONSTRAINT FK_FeedbackStudent FOREIGN KEY (Student_Student_ID) REFERENCES Student(Student_ID),
    CONSTRAINT FK_FeedbackAssignment FOREIGN KEY (Assignment_Assignment_ID) REFERENCES Assignment(Assignment_ID),
    INDEX idx_Instructor_Ins_ID (Instructor_Ins_ID),
    INDEX idx_Student_Student_ID (Student_Student_ID)
);

-- Certificate Table
CREATE TABLE Certificate (
    Certificate_ID INT PRIMARY KEY NOT NULL UNIQUE,
    Timeline INT NOT NULL,
    Certification_Date DATE NOT NULL,
    Student_Student_ID INT NOT NULL,
    CONSTRAINT FK_CertificateStudent FOREIGN KEY (Student_Student_ID) REFERENCES Student(Student_ID) ON DELETE CASCADE
);
INSERT INTO Account (Account_ID, Account_TYPE, Username, Password ) VALUES
(1011, 1, NULL, NULL),  -- Student
(1012, 1, NULL, NULL),  -- Student
(1013, 1, NULL, NULL),  -- Student


(2022, 2, NULL, NULL), -- Instructor
(2023, 2, NULL, NULL), -- Instructor


(3033, 0, NULL, NULL); -- Admin

INSERT INTO Student (Student_ID, Student_Name, Enrollment_Date, Phone_num, Email, Graduation_Date, account_Account_ID) VALUES
(1011,'bora şeşenoğlu','2022-09-01', '123-456-7880', 'student1@example.com', '2024-05-15', 1011),
(1012,'praise aremu','2021-09-01', '123-456-7881', 'student2@example.com', '2024-05-15', 1012),
(1013,'kaan özkoyuncu','2020-09-01', '123-456-7882', 'student3@example.com', '2024-05-15', 1013);
-----------
INSERT INTO Account (Account_ID, Account_TYPE, Username, Password ) VALUES
(1014, 1, NULL, NULL),  -- Student
(1015, 1, NULL, NULL),  -- Student
(1016, 1, NULL, NULL),  -- Student
(1017, 1, NULL, NULL),  -- Student

(2024, 2, NULL, NULL), -- Instructor
(2025, 2, NULL, NULL); -- Instructor

INSERT INTO Student (Student_ID, Student_Name, Enrollment_Date, Phone_num, Email, Graduation_Date, account_Account_ID) VALUES
(1014,'test','2020-09-01', '123-406-7882', 'student4@example.com', '2025-05-15', 1014),	--
(1015,'test2','2022-09-01', '123-416-7880', 'student5@example.com', '2026-05-15', 1015),	--
(1016,'boran bozkurt','2022-09-01', '123-056-7880', 'student6@example.com', '2025-05-15', 1016),	--
(1017,'dilşah bahçeci','2022-09-01', '120-456-7880', 'student7@example.com', '2026-05-15', 1017);	--

INSERT INTO Instructor (Ins_ID, Instructor_Name, Phone_num, Email, account_Account_ID) VALUES
(2024, 'ali', '134-567-0001', 'instructor03@example.com', 2024),	--
(2025, 'veli', '234-567-8001', 'instructor04@example.com', 2025)	;	--

----------
INSERT INTO Instructor (Ins_ID, Instructor_Name, Phone_num, Email, account_Account_ID) VALUES
(2023, 'ahmet', '134-567-9801', 'instructor02@example.com', 2023),
(2022, 'KMK', '234-567-8801', 'instructor01@example.com', 2022);


INSERT INTO Administration (Admin_ID, Admin_Name, account_Account_ID) VALUES
(3333, 'umut uygur', 3033);

CREATE VIEW AdminSupportViewupdated AS
SELECT
    s.Help_ID,
    s.Administration_Admin_ID,
    s.AC_Account_ID,
    s.Content,
    a.Admin_Name,
    st.Student_Name,
    i.Instructor_Name
FROM
    Support s
LEFT JOIN
    Administration a ON s.Administration_Admin_ID = a.Admin_ID
LEFT JOIN
    Student st ON s.AC_Account_ID = st.account_Account_ID
LEFT JOIN
    Instructor i ON s.AC_Account_ID = i.account_Account_ID;
    CREATE VIEW InstructorAssignmentView AS
SELECT
    a.Assignment_ID,
    a.Course_ID,
    a.Title,
    a.Deadline,
    a.Content,
    a.Student_ID,
    a.Submission_Content,
    a.Grade,
    a.Feedback_Content,
    s.Student_Name,
    c.Course_Name
FROM
    Assignment a
LEFT JOIN
    Student s ON a.Student_ID = s.Student_ID
LEFT JOIN
    Course c ON a.Course_ID = c.Course_ID;
    
DELIMITER //

CREATE TRIGGER set_student_account_type
AFTER INSERT ON Student
FOR EACH ROW
BEGIN
    UPDATE Account
    SET Account_TYPE = 1 -- Assuming 1 is the Account_TYPE for students
    WHERE Account_ID = NEW.account_Account_ID;
END; //

DELIMITER ;
DELIMITER //

CREATE TRIGGER set_admin_account_type
AFTER INSERT ON Administration
FOR EACH ROW
BEGIN
    UPDATE Account
    SET Account_TYPE = 0 -- Assuming 0 is the Account_TYPE for admins
    WHERE Account_ID = NEW.account_Account_ID;
END; //

DELIMITER ;
DELIMITER //

CREATE TRIGGER set_instructor_account_type
AFTER INSERT ON Instructor
FOR EACH ROW
BEGIN
    UPDATE Account
    SET Account_TYPE = 2 -- Assuming 2 is the Account_TYPE for instructors
    WHERE Account_ID = NEW.account_Account_ID;
END; //

DELIMITER ;

